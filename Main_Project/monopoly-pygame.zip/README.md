# Monopoly in Pygame
Recreation of the Monopoly board game in Pygame. Supports all features of the classic board game including buying properties, building houses, and trading with other players. 
